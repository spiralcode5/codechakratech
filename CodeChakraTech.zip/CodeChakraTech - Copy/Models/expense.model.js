module.exports = (sequelize, Sequelize) => {

    const expense = sequelize.define("expense", {

        expenseName: {

            type: Sequelize.STRING

        },

        expenseAmount: {

            type: Sequelize.INTEGER

        },
        Date: {
            type: Sequelize.DATE
        },
        Discription: {

            type: Sequelize.STRING

        },
        ModeofPayment: {

            type: Sequelize.STRING

        },
        
    });


    return expense;

};