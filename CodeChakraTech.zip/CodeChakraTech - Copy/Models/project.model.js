module.exports = (sequelize, Sequelize) => {

    const Project = sequelize.define("project", {

        clientName: {

            type: Sequelize.STRING

        },

        clientAddress: {

            type: Sequelize.STRING

        },

        clientEmail: {

            type: Sequelize.STRING

        },

        ClientcontactNumber: {

            type: Sequelize.INTEGER

        },
        
        projectLanguage: {

            type: Sequelize.STRING

        },

        projectType: {
            type: Sequelize.STRING
        },

        start_due_date: {

            type: Sequelize.DATE

        },

    });

    return Project;

};