module.exports = (sequelize, Sequelize) => {

    const Employee = sequelize.define("Employee", {
    
    empName: {type: Sequelize.STRING},
        
    address:{type: Sequelize.STRING},
        
    salary: {type: Sequelize.INTEGER},
          
    email: {type: Sequelize.STRING},

    contact: {type: Sequelize.INTEGER},
    });
    
    
    return Employee;
    
    };