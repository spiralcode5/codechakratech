module.exports = (sequelize, Sequelize) => {

    const Company = sequelize.define("Company", {
    
    companyName: {type: Sequelize.STRING},
    
    HRname: {type: Sequelize.STRING},
        
    address:{type: Sequelize.STRING},
        
    contact: {type: Sequelize.INTEGER},
          
    email: {type: Sequelize.STRING},
    });
    
    
    return Company;
    
    };