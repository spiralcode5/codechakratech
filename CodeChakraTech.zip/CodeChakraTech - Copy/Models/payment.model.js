module.exports = (sequelize, Sequelize) => {

    const payment = sequelize.define("payment", {
    
    S_Name:
     {
       type: Sequelize.STRING
     },
    
    Date:
     {
      type: Sequelize.DATE
     },

     Total_amount:
     {
         type: Sequelize.INTEGER
     },
     Payment_type: 
     {
       type: Sequelize.STRING
     },
     
    
    });
    
    
    return payment;
    
    };