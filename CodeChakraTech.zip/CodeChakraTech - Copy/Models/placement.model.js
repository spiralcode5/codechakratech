module.exports = (sequelize, Sequelize) => {

    const Placement = sequelize.define("placement", {

        stud_Id: {

            type: Sequelize.STRING

        },

        companyName: {

            type: Sequelize.STRING

        },

        Date: {

            type: Sequelize.DATE

        },

    });

    return Placement;

};