module.exports = (sequelize, Sequelize) => {
    const student = require('./student.model')(sequelize,Sequelize)
    const StudReport = sequelize.define("StudReport", {
    
    
    skills: {type: Sequelize.STRING},
        
    improvements:{type: Sequelize.STRING},
    });
    
    student.hasMany(StudReport)
    StudReport.belongsTo(student)
    
    return StudReport;
    };