module.exports = (sequelize, Sequelize) => {

    const Seminar = sequelize.define("Seminar", {
    
    Collagename:
     {
       type: Sequelize.STRING
     },
    
    Date:
     {
      type: Sequelize.DATE
     },

     Stream:
     {
         type: Sequelize.STRING
     },
     Number_of_students: 
     {
       type: Sequelize.INTEGER
     },
     
    
    });
    
    
    return Seminar;
    
    };