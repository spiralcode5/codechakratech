module.exports = (sequelize, Sequelize) => {

    const Batch = sequelize.define("Batch", {
    
    Batchname:
     {
       type: Sequelize.STRING
     },
    
    Starttime:
     {
      type: Sequelize.STRING
     },

     Endtime:
     {
         type: Sequelize.STRING
     },
     Duration: 
     {
       type: Sequelize.STRING
     },
     
     Mode: 
     {
        type: Sequelize.STRING
                
     },
    
    });
    
    
    return Batch;
    
    };