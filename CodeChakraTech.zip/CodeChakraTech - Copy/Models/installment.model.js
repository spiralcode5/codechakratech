
module.exports = (sequelize, Sequelize) => {
    const Payments = require('./payment.model')(sequelize,Sequelize)
    const Installment = sequelize.define("installment", {

        totalAmount: {

            type: Sequelize.INTEGER

        },

        first_installment: {

            type: Sequelize.INTEGER

        },

        second_installment: {

            type: Sequelize.INTEGER

        },

        third_installment: {

            type: Sequelize.STRING

        },

        first_installment_Date: {

            type: Sequelize.DATE

        },

        second_installment_Date: {

            type: Sequelize.DATE

        },

        third_installment_Date: {

            type: Sequelize.DATE

        },

        Remaining: {

            type: Sequelize.INTEGER

        }

    });

     
    Payments.hasMany(Installment)
    Installment.belongsTo(Payments)

    return Installment;

};