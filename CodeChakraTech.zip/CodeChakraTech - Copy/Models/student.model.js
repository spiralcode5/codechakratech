module.exports = (sequelize, Sequelize) => {
    const batches = require('./batch.model')(sequelize,Sequelize)
    const student = sequelize.define("student", {
        
        studentName: {

            type: Sequelize.STRING

        },

        contact: {

            type: Sequelize.STRING

        },
        Email: {
            type: Sequelize.STRING
        },
        Address: {

            type: Sequelize.STRING

        },
        
    });

    batches.hasMany(student)
    student.belongsTo(batches)

    return student;

};