module.exports = {
    HOST: "194.59.164.107",
    USER: "u513157518_codechakratech",
    PASSWORD: "Codechakra@2022",
    DB: "u513157518_codechakraweb",
    dialect: "mysql",
    pool: {
      max: 5,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  };