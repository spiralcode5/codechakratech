const express = require('express');
const app = express();
const cors = require('cors');

//take databases to sync so that tables are auto-generated
const companydb = require('./Models/companyORM')
const paymentdb = require('./Models/paymentORM')
const installmentdb = require('./Models/installmentORM')
const projectdb = require('./Models/projectORM')
const batchdb = require('./Models/batchORM')
const employeedb = require('./Models/employeeORM')
const expensedb = require('./Models/expenseORM')
const placementdb = require('./Models/placementORM')
const seminardb = require('./Models/seminarORM')
const studentdb = require('./Models/studentORL')
const studRepdb = require('./Models/studReportORM')

//import all the routes
const Employee = require('./Routes/employeeRoute')
const Company = require('./Routes/companyRoute')
const Batch = require('./Routes/batchRoutes')
const Seminar = require('./Routes/seminarRoutes')
const project = require('./Routes/projectRoutes')
const placement = require('./Routes/placementRoutes')
const student = require('./Routes/studentRoutes')
const expense = require('./Routes/expenseRoutes')
const payment = require('./Routes/paymentRoutes')
const installment = require('./Routes/installment.Routes')
const studReport = require('./Routes/studReportRoute')

app.use(cors());

//function to sync the tables
companydb.sequelize.sync();
paymentdb.sequelize.sync();
installmentdb.sequelize.sync();
batchdb.sequelize.sync();
employeedb.sequelize.sync();
expensedb.sequelize.sync();
placementdb.sequelize.sync();
projectdb.sequelize.sync();
seminardb.sequelize.sync();
studentdb.sequelize.sync();
studRepdb.sequelize.sync();

app.use(express.json());


app.use('/api',Employee);
app.use('/api',Company);
app.use('/api',Batch);
app.use('/api',Seminar);
app.use('/api',project);
app.use('/api',placement);
app.use('/api',student);
app.use('/api',expense);
app.use('/api',payment);
app.use('/api',studReport);
app.use('/api',installment);

app.listen(process.env.PORT || 80)