const db = require('../Models/seminarORM');

const Seminar = db.Seminar;

// Save seminar in the database
  exports.create = (req, res) => {

    Seminar.create(req.body)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while creating the seminar."
        });
      });
  };

//select all
  exports.findAll = (req, res) => {
    
    Seminar.findAll({attributes: ['id','Collagename','Date','Stream','Number_of_students']})
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving seminar."
        });
      });
  };

//by seminar 
  exports.findOne=(req,res)=>{
    const Collagename = req.params.Collagename
   
    Batch.findAll({attributes: ['id','Collagename','Date','Stream','Number_of_students'],where:{Collagename:Collagename}})
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving seminar."
      });
    });
  }

//update seminar
  exports.update = (req, res) => {
    const id = req.params.id;
  
    Seminar.update(req.body, {
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "seminar was updated successfully."
          });
        } else {
          res.send({
            message: `Cannot update seminar with id=${id}. Maybe seminar was not found or req.body is empty!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating seminar with id=" + id
        });
      });
  };


  //delete seminar
  exports.dropOne = (req, res) => {
    const id = req.params.id;
  
    Seminar.destroy({
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "seminar was deleted successfully!"
          });
        } else {
          res.send({
            message: `Cannot delete Seminar with id=${id}. Maybe Batch was not found!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Could not delete seminar with id=" + id
        });
      });
    }

    //selectOne
    exports.selectOne = (req, res) => {
      const id = req.params.id;
    
      Seminar.findByPk(id)
        .then(data => {
          res.send(data);
        })
        .catch(err => {
          res.status(500).send({
            message: "Error retrieving seminar with id=" + id
          });
        });
    };