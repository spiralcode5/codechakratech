const db = require('../Models/paymentORM');

const payment =db.payment;

exports.create = (req, res) => {

  // Save payment in the database
    payment.create(req.body)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while creating the payment."
        });
      });
  };

//select all
  exports.findAll = (req, res) => {

  
    payment.findAll({attributes: ['id', 'S_Name','Date','Total_amount','Payment_type']})
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving payments."
        });
      });
  };

//by batch 
  exports.findOne=(req,res)=>{
    const S_Name = req.params.S_Name
   
    payment.findAll({attributes: ['id', 'S_Name','Date','Total_amount','Payment_type'],where:{S_Name:S_Name}})
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving payments."
      });
    });
  }

//update batch
  exports.update = (req, res) => {
    const id = req.params.id;
  
    payment.update(req.body, {
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "payment was updated successfully."
          });
        } else {
          res.send({
            message: `Cannot update payment with id=${id}. Maybe payment was not found or req.body is empty!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating payment with id=" + id
        });
      });
  };


  //delete Batch
  exports.dropOne = (req, res) => {
    const id = req.params.id;
  
    payment.destroy({
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "payment was deleted successfully!"
          });
        } else {
          res.send({
            message: `Cannot delete payment with id=${id}. Maybe Batch was not found!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Could not delete payment with id=" + id
        });
      });
    }

    //selectOne
    exports.selectOne = (req, res) => {
      const id = req.params.id;
    
      payment.findByPk(id)
        .then(data => {
          res.send(data);
        })
        .catch(err => {
          res.status(500).send({
            message: "Error retrieving payment with id=" + id
          });
        });
    };