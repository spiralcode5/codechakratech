
const db = require('../Models/placementORM');

const Placement =db.Placement;

exports.create = (req, res) => {
  
    // Save project details in the database
    Placement.create(req.body)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while filling the project details."
        });
      });
  };

//find all
  exports.findAll = (req, res) => {
  
    Placement.findAll({attributes: ['stud_Id', 'companyName','Date']})
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving details."
        });
      });
  };

//update project
  exports.update = (req, res) => {
    const id = req.params.id;
  
    Placement.update(req.body, {
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "Details was updated successfully."
          });
        } else {
          res.send({
            message: `Cannot update details with id=${id}. Maybe something was not found or req.body is empty!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating details with id=" + id
        });
      });
  };

  //delete details
  exports.dropOne = (req, res) => {
    const id = req.params.id;
  
    Placement.destroy({
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "Details was deleted successfully!"
          });
        } else {
          res.send({
            message: `Cannot delete Details with id=${id}. Maybe details was not found!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Could not delete Details with id=" + id
        });
      });
    }

    exports.selectOne = (req, res) => {
      const id = req.params.id;
    
      Pl.findByPk(id)
        .then(data => {
          res.send(data);
        })
        .catch(err => {
          res.status(500).send({
            message: "Error retrieving Details with id=" + id
          });
        });
    };