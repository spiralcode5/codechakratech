const db = require('../Models/batchORM');

const Batch =db.Batch;

exports.create = (req, res) => {

  // Save batch in the database
    Batch.create(req.body)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while creating the Survey."
        });
      });
  };


//select dorwpdown

//   exports.selectDD = (req,res) => {
//     batch.findAll({ attributes: ['id', 'Batchname'], })
//       .then(data => {
//         res.send(data);
//       })
//       .catch(err => {
//         res.status(500).send({
//           message:
//             err.message || "Some error occurred while retrieving Surveys."
//         });
//       });
//   }

//select all
  exports.findAll = (req, res) => {

  
    Batch.findAll({attributes: ['id', 'Batchname','Starttime','Endtime','Duration','Mode']})
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving Surveys."
        });
      });
  };

//by batch 
  exports.findOne=(req,res)=>{
    const Batchname = req.params.Batchname
   
    Batch.findAll({attributes: ['id', 'Batchname','Starttime','Endtime','Duration','Mode'],where:{Batchname:Batchname}})
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving Surveys."
      });
    });
  }

//update batch
  exports.update = (req, res) => {
    const id = req.params.id;
  
    Batch.update(req.body, {
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "Batch was updated successfully."
          });
        } else {
          res.send({
            message: `Cannot update Survey with id=${id}. Maybe Survey was not found or req.body is empty!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating Batch with id=" + id
        });
      });
  };


  //delete Batch
  exports.dropOne = (req, res) => {
    const id = req.params.id;
  
    Batch.destroy({
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "Batch was deleted successfully!"
          });
        } else {
          res.send({
            message: `Cannot delete Batch with id=${id}. Maybe Batch was not found!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Could not delete Batch with id=" + id
        });
      });
    }

    //selectOne
    exports.selectOne = (req, res) => {
      const id = req.params.id;
    
      Batch.findByPk(id)
        .then(data => {
          res.send(data);
        })
        .catch(err => {
          res.status(500).send({
            message: "Error retrieving Batch with id=" + id
          });
        });
    };