const db = require('../Models/expenseORM');

const expense =db.expense;

exports.create = (req, res) => {

  
    // Save surveys in the database
    expense.create(req.body)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while giving the expense name."
        });
      });
  };


//select all
  exports.findAll = (req, res) => {

  
    expense.findAll({attributes: ['id','expenseName','expenseAmount','Date','Discription','ModeofPayment']})
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred ."
        });
      });
  };

//by vilage 
  exports.findOne=(req,res)=>{
    const expenseName = req.params.expenseName
   
    expense.findAll({attributes: ['id','expenseName','expenseAmount','Date','Discription','ModeofPayment'],where:{expenseName:expenseName}})
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred ."
      });
    });
  }

//update surveys
  exports.update = (req, res) => {
    const id = req.params.id;
  
    expense.update(req.body, {
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "expense  was updated successfully."
          });
        } else {
          res.send({
            message: `Cannot update expense with id=${id}. Maybe expense was not found or req.body is empty!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating student with id=" + id
        });
      });
  };


  //delete survey
  exports.dropOne = (req, res) => {
    const id = req.params.id;
  
    expense.destroy({
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "expense was deleted successfully!"
          });
        } else {
          res.send({
            message: `Cannot delete student with id=${id}. Maybe student was not found!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Could not delete student with id=" + id
        });
      });
    }

    exports.selectOne = (req, res) => {
      const id = req.params.id;
    
      expense.findByPk(id)
        .then(data => {
          res.send(data);
        })
        .catch(err => {
          res.status(500).send({
            message: "Error retrieving student with id=" + id
          });
        });
    };