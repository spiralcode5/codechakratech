const db = require('../Models/studentORL');

const student =db.student;

exports.create = (req, res) => {

  
    // Save surveys in the database
    student.create(req.body)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while giving the student name."
        });
      });
  };

//select all
  exports.findAll = (req, res) => {

  
    student.findAll({attributes: ['id', 'studentName','contact','Email','Address','batch_id','type','mobileNumber']})
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred ."
        });
      });
  };

//by vilage 
  exports.findOne=(req,res)=>{
    const studenteName = req.params.studenteName
   
    student.findAll({attributes: ['id', 'studentName','contact','Email','Address','batch_id','type','mobileNumber'],where:{studenteName:studenteName}})
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred ."
      });
    });
  }

//update surveys
  exports.update = (req, res) => {
    const id = req.params.id;
  
    student.update(req.body, {
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "student  was updated successfully."
          });
        } else {
          res.send({
            message: `Cannot update student with id=${id}. Maybe student was not found or req.body is empty!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating student with id=" + id
        });
      });
  };


  //delete survey
  exports.dropOne = (req, res) => {
    const id = req.params.id;
  
    student.destroy({
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "student was deleted successfully!"
          });
        } else {
          res.send({
            message: `Cannot delete student with id=${id}. Maybe student was not found!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Could not delete student with id=" + id
        });
      });
    }

    exports.selectOne = (req, res) => {
      const id = req.params.id;
    
      student.findByPk(id)
        .then(data => {
          res.send(data);
        })
        .catch(err => {
          res.status(500).send({
            message: "Error retrieving student with id=" + id
          });
        });
    };