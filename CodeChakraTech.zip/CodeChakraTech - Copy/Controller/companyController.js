const db = require('../Models/companyORM');

const Company = db.Company;

exports.create = (req, res) => {
  
    // Save Companies in the database
    Company.create(req.body)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while creating the Company."
        });
      });
  };



//select all
  exports.findAll = (req, res) => {

  
    Company.findAll({attributes: ['id', 'companyName','HRname','address','contact','email']})
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving Companys."
        });
      });
  };

//by Company name 
  exports.findOne=(req,res)=>{
    const empName = req.params.empName
   
    Company.findAll({attributes: ['id', 'companyName','HRname','address','contact','email'],where:{empName:empName}})
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving Companies."
      });
    });
  }

//update Companys
  exports.update = (req, res) => {
    const id = req.params.id;
  
    Company.update(req.body, {
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "Company was updated successfully."
          });
        } else {
          res.send({
            message: `Cannot update Company with id=${id}. Maybe Company was not found or req.body is empty!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating Company with id=" + id
        });
      });
  };


  //delete Company
  exports.dropOne = (req, res) => {
    const id = req.params.id;
  
    Company.destroy({
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "Company was deleted successfully!"
          });
        } else {
          res.send({
            message: `Cannot delete Company with id=${id}. Maybe Company was not found!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Could not delete Company with id=" + id
        });
      });
    }

    exports.selectOne = (req, res) => {
      const id = req.params.id;
    
      Company.findByPk(id)
        .then(data => {
          res.send(data);
        })
        .catch(err => {
          res.status(500).send({
            message: "Error retrieving Company with id=" + id
          });
        });
    };