const db = require('../Models/studReportORM');

const StudReport = db.StudReport;

exports.create = (req, res) => {
  
    // Save Companies in the database
    StudReport.create(req.body)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while creating the Student Report."
        });
      });
  };



//select all
  exports.findAll = (req, res) => {

  
    StudReport.findAll({attributes: ['id', 'stud_id','skills','improvements']})
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving Student Report."
        });
      });
  };

//by StudReport name 
//   exports.findOne=(req,res)=>{
//     const empName = req.params.empName
   
//     StudReport.findAll({attributes: ['id', 'companyName','HRname','address','contact','email'],where:{empName:empName}})
//     .then(data => {
//       res.send(data);
//     })
//     .catch(err => {
//       res.status(500).send({
//         message:
//           err.message || "Some error occurred while retrieving Student Reports."
//       });
//     });
//   }

//update Companys
  exports.update = (req, res) => {
    const id = req.params.id;
  
    StudReport.update(req.body, {
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "Student Report was updated successfully."
          });
        } else {
          res.send({
            message: `Cannot update Student Report with id=${id}. Maybe Report was not found or req.body is empty!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating Report with id=" + id
        });
      });
  };


  //delete Company
  exports.dropOne = (req, res) => {
    const id = req.params.id;
  
    StudReport.destroy({
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "Student Report was deleted successfully!"
          });
        } else {
          res.send({
            message: `Cannot delete Student Report with id=${id}. Maybe Student Report was not found!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Could not delete Student Report with id=" + id
        });
      });
    }

    exports.selectOne = (req, res) => {
      const id = req.params.id;
    
      StudReport.findByPk(id)
        .then(data => {
          res.send(data);
        })
        .catch(err => {
          res.status(500).send({
            message: "Error retrieving Student Report with id=" + id
          });
        });
    };