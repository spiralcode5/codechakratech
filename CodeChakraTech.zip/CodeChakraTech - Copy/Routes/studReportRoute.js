const{findAll,create,update,dropOne,selectOne} = require('../Controller/studReportController');
const router = require('express').Router();


router.post('/studreport',create);

router.get('/studreport',findAll);

// router.get('/selectVillage',selectDD);

// router.get('/studreport/:companyName',findOne);

// Retrieve a single studreport with id
router.get("/studreport/getOne/:id", selectOne);

// Update a studreport with id
router.put("/studreport/update/:id", update);

// Delete a studreport with id
router.delete("/studreport/delete/:id", dropOne);


module.exports = router;