const{findAll,findOne,create,update,dropOne,selectOne} = require('../Controller/employeeController');
const router = require('express').Router();


router.post('/employee',create);

router.get('/employee',findAll);

// router.get('/selectVillage',selectDD);

router.get('/employee/:empName',findOne);

// Retrieve a single Employee with id
router.get("/employee/getOne/:id", selectOne);

// Update a Employee with id
router.put("/employee/update/:id", update);

// Delete a Employee with id
router.delete("/employee/delete/:id", dropOne);

module.exports = router;