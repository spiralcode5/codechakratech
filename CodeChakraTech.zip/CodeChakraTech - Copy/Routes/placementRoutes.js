const{create,findAll,update,dropOne,selectOne} = require('../Controller/placementController');
const router = require('express').Router();

router.post('/placement',create);

router.get('/placement',findAll);

// Retrieve a single detail with id
router.get("/placement/getOne/:id", selectOne);

// Update a detail with id
router.put("/placement/update/:id", update);

// Delete a delete with id
router.delete("/placement/delete/:id", dropOne);

module.exports = router;