const{findAll,findOne,create,update,dropOne,selectOne} = require('../Controller/companyController');
const router = require('express').Router();


router.post('/company',create);

router.get('/company',findAll);

// router.get('/selectVillage',selectDD);

router.get('/company/:companyName',findOne);

// Retrieve a single company with id
router.get("/company/getOne/:id", selectOne);

// Update a company with id
router.put("/company/update/:id", update);

// Delete a company with id
router.delete("/company/delete/:id", dropOne);


module.exports = router;