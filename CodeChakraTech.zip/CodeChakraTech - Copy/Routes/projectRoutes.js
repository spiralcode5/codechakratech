const{create,findAll,update,dropOne,selectOne} = require('../Controller/projectController');
const router = require('express').Router();

router.post('/project',create);

router.get('/project',findAll);

// Retrieve a single detail with id
router.get("/project/getOne/:id", selectOne);

// Update a detail with id
router.put("/project/update/:id", update);

// Delete a delete with id
router.delete("/project/delete/:id", dropOne);

module.exports = router;