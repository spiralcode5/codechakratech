const{findAll,findOne,create,update,dropOne,selectOne} = require('../Controller/seminarController');
const router = require('express').Router();


router.post('/seminar',create);


router.get('/seminar',findAll);


router.get('/seminar/:collagename',findOne);

// Retrieve a single seminar with id
router.get("/seminar/getOne/:id", selectOne);

// Update a seminar with id
router.put("/seminar/update/:id", update);

// Delete a seminar with id
router.delete("/seminar/delete/:id", dropOne);

module.exports = router;