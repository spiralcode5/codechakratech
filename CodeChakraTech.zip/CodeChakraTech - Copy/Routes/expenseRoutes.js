const{findAll,findOne,create,update,dropOne,selectOne} = require('../Controller/expensecontroller');
const router = require('express').Router();


router.post('/expense',create);


router.get('/expense',findAll);

// router.get('/selectVillage',selectDD);

router.get('/expense/:batchname',findOne);

// Retrieve a single Survey with id
router.get("/expense/getOne/:id", selectOne);

// Update a Survey with id
router.put("/expense/update/:id", update);

// Delete a Survey with id
router.delete("/expense/delete/:id", dropOne);

module.exports = router;