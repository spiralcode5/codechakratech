const{findAll,findOne,create,update,dropOne,selectOne} = require('../Controller/studcontroller');
const router = require('express').Router();


router.post('/student',create);


router.get('/student',findAll);

// router.get('/selectVillage',selectDD);

router.get('/student/:batchname',findOne);

// Retrieve a single Survey with id
router.get("/student/getOne/:id", selectOne);

// Update a Survey with id
router.put("/student/update/:id", update);

// Delete a Survey with id
router.delete("/student/delete/:id", dropOne);

module.exports = router;