const{findAll,findOne,create,update,dropOne,selectOne} = require('../Controller/batchController');
const router = require('express').Router();


router.post('/batch',create);


router.get('/batch',findAll);

// router.get('/selectVillage',selectDD);

router.get('/batch/:batchname',findOne);

// Retrieve a single Survey with id
router.get("/batch/getOne/:id", selectOne);

// Update a Survey with id
router.put("/batch/update/:id", update);

// Delete a Survey with id
router.delete("/batch/delete/:id", dropOne);

module.exports = router;