const{create,findAll,update,dropOne,selectOne} = require('../Controller/installmentController');
const router = require('express').Router();

router.post('/installment',create);

router.get('/installment',findAll);

// Retrieve a single detail with id
router.get("/installment/getOne/:id", selectOne);

// Update a detail with id
router.put("/installment/update/:id", update);

// Delete a delete with id
router.delete("/installment/delete/:id", dropOne);

module.exports = router;